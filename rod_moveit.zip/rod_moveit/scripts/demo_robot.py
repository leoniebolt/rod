#!/usr/bin/env python

import sys
import rospy
import moveit_commander
import geometry_msgs.msg
from copy import deepcopy

def move_arm(group_name, pose, description=""):
    group = moveit_commander.MoveGroupCommander(group_name)
    group.set_pose_reference_frame("world")
    group.set_planning_time(15.0)
    group.set_num_planning_attempts(10)
    group.set_max_velocity_scaling_factor(0.5)
    group.set_max_acceleration_scaling_factor(0.5)
    group.allow_replanning(True)

    group.set_start_state_to_current_state()
    group.set_pose_target(pose)

    rospy.loginfo(f"Moving {group_name} to {description}...")
    success = group.go(wait=True)
    group.stop()
    group.clear_pose_targets()

    if not success:
        rospy.logwarn(f"{group_name} failed to move to {description}")
    return success

def main():
    moveit_commander.roscpp_initialize(sys.argv)
    rospy.init_node("demo_robot", anonymous=True)
    rospy.sleep(1)

    # SCARA - Positionen für Greifen einer Schachtel
    pre_grasp = geometry_msgs.msg.Pose()
    pre_grasp.position.x = 2.2
    pre_grasp.position.y = 0.2
    pre_grasp.position.z = 1.3  # über der Schachtel
    pre_grasp.orientation.w = 1.0

    grasp = deepcopy(pre_grasp)
    grasp.position.z = 1.0  # tiefer – greift die Schachtel

    post_grasp = deepcopy(pre_grasp)  # zurückfahren

    drop = deepcopy(pre_grasp)
    drop.position.x = 2.2
    drop.position.y = 1.2  # Dropzone (z. B. Förderband)

    # SIXAXIS - Positionen zum Abholen
    sixaxis_pre_grasp = geometry_msgs.msg.Pose()
    sixaxis_pre_grasp.position.x = -0.9
    sixaxis_pre_grasp.position.y = -1.1
    sixaxis_pre_grasp.position.z = 1.0
    sixaxis_pre_grasp.orientation.w = 1.0

    sixaxis_grasp = deepcopy(sixaxis_pre_grasp)
    sixaxis_grasp.position.z = 1.0

    sixaxis_drop = deepcopy(sixaxis_pre_grasp)
    sixaxis_drop.position.x = -1.0
    sixaxis_drop.position.y = -1.2

    # Ablauf
    move_arm("scara", pre_grasp, "scara pre-grasp")
    move_arm("scara", grasp, "scara grasp")
    # → Greifer schließen (optional)
    move_arm("scara", post_grasp, "scara post-grasp")
    move_arm("scara", drop, "scara drop")
    # → Greifer öffnen (optional)

    rospy.sleep(1)

    move_arm("sixaxis", sixaxis_pre_grasp, "sixaxis pre-grasp")
    move_arm("sixaxis", sixaxis_grasp, "sixaxis grasp")
    # → Greifer schließen (optional)
    move_arm("sixaxis", sixaxis_pre_grasp, "sixaxis post-grasp")
    move_arm("sixaxis", sixaxis_drop, "sixaxis drop")
    # → Greifer öffnen (optional)

    rospy.loginfo("Done!")

if __name__ == '__main__':
    main()
